import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/onboarding_constants.dart';

/// Mixin for managing system UI behavior in onboarding screens
/// Handles status bar configuration and navigation bar auto-hide functionality
mixin SystemUIMixin<T extends StatefulWidget>
    on State<T>, WidgetsBindingObserver {
  Timer? _navigationBarTimer;

  /// Setup status bar with transparent background and proper brightness
  void setupStatusBar() {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness: Brightness.light,
      systemNavigationBarColor: Colors.transparent,
    ));
    startNavigationBarHideTimer();
  }

  /// Start timer to automatically hide navigation bar
  void startNavigationBarHideTimer() {
    _navigationBarTimer?.cancel();
    _navigationBarTimer = Timer(OnboardingConstants.statusBarHideDelay, () {
      SystemChrome.setEnabledSystemUIMode(
        SystemUiMode.manual,
        overlays: [SystemUiOverlay.top],
      );
    });
  }

  /// Cleanup system UI resources
  void cleanupSystemUI() {
    _navigationBarTimer?.cancel();
    _navigationBarTimer = null;
  }

  /// Handle app lifecycle state changes
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed) {
      setupStatusBar();
    }
  }

  /// Handle metrics changes (keyboard show/hide, orientation changes)
  @override
  void didChangeMetrics() {
    super.didChangeMetrics();
    startNavigationBarHideTimer();
  }

  /// Initialize system UI settings
  void initializeSystemUI() {
    WidgetsBinding.instance.addObserver(this);
    setupStatusBar();
  }

  /// Dispose system UI resources
  void disposeSystemUI() {
    _navigationBarTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
  }

  /// Trigger navigation bar hide on user interaction
  void onUserInteraction() {
    startNavigationBarHideTimer();
  }

  /// Check if navigation bar timer is active
  bool get isNavigationBarTimerActive => _navigationBarTimer?.isActive ?? false;

  /// Get remaining time for navigation bar hide
  Duration? get navigationBarHideTimeRemaining {
    if (_navigationBarTimer?.isActive ?? false) {
      // This is an approximation since Timer doesn't expose remaining time
      return OnboardingConstants.statusBarHideDelay;
    }
    return null;
  }
}
