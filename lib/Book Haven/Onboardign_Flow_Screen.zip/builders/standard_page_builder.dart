import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../widgets/colors.dart';
import '../constants/onboarding_constants.dart';
import '../models/bk_onboarding_data.dart' as BkData;
import '../services/onboarding_navigation_service.dart';
import '../widgets/bk_onboarding_components.dart' as BkWidgets;

/// Builder for standard pages in the BK onboarding flow
class StandardPageBuilder {
  /// Build a standard page with navigation, image, and content
  static Widget build({
    required BkData.BkOnboardingPageData pageData,
    required int pageIndex,
    required VoidCallback onNext,
    required VoidCallback onPrevious,
    required VoidCallback onSkip,
    required PageController pageController,
    required BuildContext context,
  }) {
    return Scaffold(
      backgroundColor: bkBackgroundColor,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final screenHeight = constraints.maxHeight;
            final imageHeight = screenHeight * 0.5;
            final contentHeight = screenHeight * 0.4;
            final bottomHeight =
                (pageData.bottomText != null && pageData.bottomLinkText != null)
                    ? 60.0
                    : 0.0;

            return Stack(
              children: [
                // Image section
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  height: imageHeight,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: pageData.svgIcon != null
                        ? SvgPicture.asset(
                            pageData.svgIcon!,
                            fit: BoxFit.contain,
                          )
                        : const SizedBox(),
                  ),
                ),

                // Navigation buttons
                if (pageData.hasBackButton)
                  Positioned(
                    top: OnboardingConstants.topNavigationOffset,
                    left: OnboardingConstants.horizontalPadding,
                    child: BkWidgets.BkBackButton(onTap: onPrevious),
                  ),

                if (pageData.hasSkipButton)
                  Positioned(
                    top: OnboardingConstants.topNavigationOffset,
                    right: OnboardingConstants.horizontalPadding,
                    child: BkWidgets.BkSkipButton(onTap: onSkip),
                  ),

                // Content section
                Positioned(
                  top: imageHeight - 20,
                  left: OnboardingConstants.horizontalPadding,
                  right: OnboardingConstants.horizontalPadding,
                  height: contentHeight,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: OnboardingConstants.cardPadding,
                      vertical: OnboardingConstants.cardPadding,
                    ),
                    decoration: BoxDecoration(
                      color: bhPrimary1
                          .withOpacity(OnboardingConstants.backgroundOpacity),
                      borderRadius: BorderRadius.circular(
                          OnboardingConstants.borderRadius),
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          BkWidgets.BkPageMessage(
                            header: pageData.title,
                            details: pageData.description,
                          ),

                          const SizedBox(
                              height: OnboardingConstants.mediumSpacing),

                          // Buttons
                          if (pageData.buttons != null)
                            ..._buildButtons(
                                pageData.buttons!, pageController, context),
                        ],
                      ),
                    ),
                  ),
                ),

                // Bottom section
                if (pageData.bottomText != null &&
                    pageData.bottomLinkText != null)
                  Positioned(
                    bottom: 0,
                    left: OnboardingConstants.horizontalPadding,
                    right: OnboardingConstants.horizontalPadding,
                    height: bottomHeight,
                    child: Center(
                      child: BkWidgets.BkBottomLinkText(
                        normalText: pageData.bottomText!,
                        linkText: pageData.bottomLinkText!,
                        onTap: () =>
                            OnboardingNavigationService.handleBottomLinkTap(
                          linkText: pageData.bottomLinkText!,
                          pageController: pageController,
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  /// Build buttons for standard pages
  static List<Widget> _buildButtons(
    List<BkData.BkButton> buttons,
    PageController pageController,
    BuildContext context,
  ) {
    debugPrint(
        '📱 StandardPageBuilder._buildButtons called with ${buttons.length} buttons');
    return buttons.asMap().entries.map((entry) {
      final button = entry.value;
      debugPrint('📱 Building button: "${button.text}"');
      return Column(
        children: [
          BkWidgets.BkCustomButton(
            text: button.text,
            icon: button.icon,
            onTap: () {
              debugPrint('📱 🔥 Button "${button.text}" tapped!');
              OnboardingNavigationService.handleButtonTap(
                buttonText: button.text,
                pageController: pageController,
                context: context,
              );
            },
            backgroundColor: button.backgroundColor,
            textColor: button.textColor,
          ),
          if (entry.key < buttons.length - 1)
            const SizedBox(height: OnboardingConstants.smallSpacing),
        ],
      );
    }).toList();
  }
}
