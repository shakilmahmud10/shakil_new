import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../widgets/colors.dart';
import '../constants/onboarding_constants.dart';
import '../models/bk_onboarding_data.dart' as BkData;
import '../widgets/bk_onboarding_components.dart' as BkWidgets;

/// Builder for welcome pages in the BK onboarding flow
class WelcomePageBuilder {
  /// Build a welcome page with image and content card
  static Widget build({
    required BkData.BkOnboardingPageData pageData,
    required int pageIndex,
    required VoidCallback onNext,
  }) {
    return Column(
      children: [
        // Top section with image
        Expanded(
          flex: OnboardingConstants.topSectionFlex,
          child: Center(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(
                horizontal: OnboardingConstants.largeSpacing + 16,
              ),
              child: pageData.svgIcon != null
                  ? SvgPicture.asset(
                      pageData.svgIcon!,
                      fit: BoxFit.contain,
                    )
                  : const SizedBox(),
            ),
          ),
        ),

        // Bottom section with content card
        Expanded(
          flex: OnboardingConstants.bottomSectionFlex,
          child: Container(
            margin: const EdgeInsets.symmetric(
              horizontal: OnboardingConstants.horizontalPadding,
              vertical: OnboardingConstants.verticalPadding,
            ),
            padding: const EdgeInsets.symmetric(
              horizontal: OnboardingConstants.horizontalPadding,
              vertical: OnboardingConstants.verticalPadding,
            ),
            decoration: BoxDecoration(
              color: bhCardBg.withOpacity(OnboardingConstants.cardOpacity),
              borderRadius:
                  BorderRadius.circular(OnboardingConstants.borderRadius),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                BkWidgets.BkPageMessage(
                  header: pageData.title,
                  details: pageData.description,
                ),
                const SizedBox(height: OnboardingConstants.headerSpacing),

                BkWidgets.BkCustomButton(
                  text: pageData.buttonText,
                  icon: pageData.buttonIcon,
                  onTap: onNext,
                  backgroundColor: bhPrimary1,
                  textColor: Colors.white,
                  isIconOnly: pageData.buttonIcon != null &&
                      pageData.buttonText.isEmpty,
                ),

                const SizedBox(height: OnboardingConstants.largeSpacing),

                // Page indicator for welcome pages only (first 3 pages)
                if (pageIndex < OnboardingConstants.welcomePagesCount)
                  BkWidgets.BkPageIndicator(
                    currentIndex: pageIndex,
                    totalPages: OnboardingConstants.welcomePagesCount,
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
