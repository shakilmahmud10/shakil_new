import 'package:flutter/material.dart';
import 'bk_onboarding_flow_screen.dart';

/// Example usage of the BkOnboardingFlowScreen
/// 
/// This demonstrates how to integrate the Book Haven onboarding flow
/// into your Flutter application.

class ExampleUsage extends StatelessWidget {
  const ExampleUsage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Book Haven Demo'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Navigate to the complete onboarding flow
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const BkOnboardingFlowScreen(),
              ),
            );
          },
          child: const Text('Start Book Haven Onboarding'),
        ),
      ),
    );
  }
}

/// Alternative usage: Direct integration in main app flow
class MainAppExample extends StatefulWidget {
  const MainAppExample({super.key});

  @override
  State<MainAppExample> createState() => _MainAppExampleState();
}

class _MainAppExampleState extends State<MainAppExample> {
  bool _shouldShowOnboarding = true; // This could come from SharedPreferences

  @override
  Widget build(BuildContext context) {
    // Show onboarding on first app launch
    if (_shouldShowOnboarding) {
      return const BkOnboardingFlowScreen();
    }
    
    // Show main app content
    return const MainAppContent();
  }
}

class MainAppContent extends StatelessWidget {
  const MainAppContent({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('Main App Content'),
      ),
    );
  }
}