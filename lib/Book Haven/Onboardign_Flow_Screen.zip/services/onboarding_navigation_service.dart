import 'package:flutter/material.dart';
import '../constants/onboarding_constants.dart';
import '../models/bk_onboarding_data.dart' as BkData;

/// Navigation service for BK Onboarding Flow
/// Centralizes all navigation logic and page routing
class OnboardingNavigationService {
  /// Navigate to a specific page with bounds checking
  static void navigateToPage(PageController controller, int pageIndex) {
    debugPrint('🚀 OnboardingNavigationService.navigateToPage called');
    debugPrint('🚀 Target page index: $pageIndex');
    debugPrint('🚀 Current page: ${getCurrentPageIndex(controller)}');
    debugPrint('🚀 Total pages: ${BkData.BkOnboardingData.pages.length}');

    // Add bounds checking to prevent crashes
    if (pageIndex >= 0 && pageIndex < BkData.BkOnboardingData.pages.length) {
      debugPrint(
          '🚀 Navigation bounds check passed - animating to page $pageIndex');
      controller.animateToPage(
        pageIndex,
        duration: OnboardingConstants.pageAnimationDuration,
        curve: Curves.easeInOut,
      );
      debugPrint('🚀 Animation command sent');
    } else {
      debugPrint(
          '🚀 ❌ Invalid page index: $pageIndex. Max index: ${BkData.BkOnboardingData.pages.length - 1}');
    }
  }

  /// Navigate to next page
  static void nextPage(PageController controller, int currentIndex) {
    if (currentIndex < BkData.BkOnboardingData.pages.length - 1) {
      controller.nextPage(
        duration: OnboardingConstants.pageAnimationDuration,
        curve: Curves.easeInOut,
      );
    }
  }

  /// Navigate to previous page
  static void previousPage(PageController controller, int currentIndex) {
    if (currentIndex > 0) {
      controller.previousPage(
        duration: OnboardingConstants.pageAnimationDuration,
        curve: Curves.easeInOut,
      );
    }
  }

  /// Skip to main menu (complete onboarding)
  static void skipToMainMenu(BuildContext context) {
    Navigator.of(context).popUntil((route) => route.isFirst);
  }

  /// Handle button tap based on button text
  static void handleButtonTap({
    required String buttonText,
    required PageController pageController,
    required BuildContext context,
  }) {
    debugPrint('🔍 OnboardingNavigationService.handleButtonTap called');
    debugPrint('🔍 Button text: "$buttonText"');
    debugPrint('🔍 Current page: ${getCurrentPageIndex(pageController)}');

    if (buttonText.contains(OnboardingConstants.emailButtonPattern)) {
      debugPrint(
          '🔍 Email pattern matched - navigating to login form (index ${OnboardingConstants.loginFormPageIndex})');
      // Go to login form page (page 6 = index 5)
      navigateToPage(pageController, OnboardingConstants.loginFormPageIndex);
    } else if (buttonText == OnboardingConstants.signInButtonText) {
      debugPrint(
          '🔍 Sign In matched - navigating to login options (index ${OnboardingConstants.loginOptionsPageIndex})');
      // Go to login options (page 5 = index 4)
      navigateToPage(pageController, OnboardingConstants.loginOptionsPageIndex);
    } else if (buttonText == OnboardingConstants.createAccountButtonText) {
      debugPrint(
          '🔍 Create Account matched - navigating to signup form (index ${OnboardingConstants.signupFormPageIndex})');
      // Go to signup form (page 7 = index 6)
      navigateToPage(pageController, OnboardingConstants.signupFormPageIndex);
    } else {
      debugPrint('🔍 No specific match - using default next page navigation');
      // Default: go to next page
      nextPage(pageController, getCurrentPageIndex(pageController));
    }
  }

  /// Handle bottom link text navigation
  static void handleBottomLinkTap({
    required String linkText,
    required PageController pageController,
  }) {
    if (linkText.contains(OnboardingConstants.createLinkPattern)) {
      // Go to signup (page 7 = index 6)
      navigateToPage(pageController, OnboardingConstants.signupFormPageIndex);
    } else {
      // Go to login form (page 6 = index 5)
      navigateToPage(pageController, OnboardingConstants.loginFormPageIndex);
    }
  }

  /// Handle form page navigation
  static void handleFormPageNavigation({
    required BkData.BkOnboardingPageData pageData,
    required PageController pageController,
    required BuildContext context,
  }) {
    if (pageData.isLoginPage) {
      // Go to signup after login (page 7 = index 6)
      navigateToPage(pageController, OnboardingConstants.signupFormPageIndex);
    } else {
      // Complete onboarding
      skipToMainMenu(context);
    }
  }

  /// Get current page index from controller
  static int getCurrentPageIndex(PageController controller) {
    return controller.page?.round() ?? 0;
  }

  /// Check if current page is a form page
  static bool isFormPage(int pageIndex) {
    if (pageIndex < 0 || pageIndex >= BkData.BkOnboardingData.pages.length) {
      return false;
    }
    return BkData.BkOnboardingData.pages[pageIndex].hasFormFields;
  }

  /// Check if current page is a welcome page
  static bool isWelcomePage(int pageIndex) {
    if (pageIndex < 0 || pageIndex >= BkData.BkOnboardingData.pages.length) {
      return false;
    }
    return BkData.BkOnboardingData.pages[pageIndex].isWelcomePage;
  }

  /// Get page type description for debugging
  static String getPageTypeDescription(int pageIndex) {
    if (pageIndex < 0 || pageIndex >= BkData.BkOnboardingData.pages.length) {
      return 'Invalid page';
    }

    final page = BkData.BkOnboardingData.pages[pageIndex];
    if (page.isWelcomePage) return 'Welcome page';
    if (page.hasFormFields) return 'Form page';
    return 'Standard page';
  }
}
