import 'package:flutter/material.dart';
import '../models/bk_onboarding_data.dart' as BkData;

/// State management class for BK Onboarding Flow
/// Handles all form controllers, focus nodes, and form-related state
class OnboardingStateManager {
  // Form controllers for input fields
  final Map<String, TextEditingController> _controllers = {};
  final Map<String, FocusNode> _focusNodes = {};

  // Form state
  String? _activeFocusField;
  bool _rememberMe = false;

  // Getters
  Map<String, TextEditingController> get controllers => _controllers;
  Map<String, FocusNode> get focusNodes => _focusNodes;
  String? get activeFocusField => _activeFocusField;
  bool get rememberMe => _rememberMe;

  // Setter for remember me
  set rememberMe(bool value) {
    _rememberMe = value;
  }

  /// Initialize all controllers and focus nodes based on page data
  void initializeControllers() {
    try {
      for (int i = 0; i < BkData.BkOnboardingData.pages.length; i++) {
        final page = BkData.BkOnboardingData.pages[i];
        if (page.hasFormFields && page.formFields != null) {
          for (int j = 0; j < page.formFields!.length; j++) {
            final fieldKey = '${i}_${j}';
            _controllers[fieldKey] = TextEditingController();
            _focusNodes[fieldKey] = FocusNode();
            _focusNodes[fieldKey]!
                .addListener(() => _updateFocusState(fieldKey));
          }
        }
      }
    } catch (e) {
      debugPrint('Error initializing controllers: $e');
    }
  }

  /// Dispose all controllers and focus nodes
  void disposeControllers() {
    _controllers.values.forEach((controller) => controller.dispose());
    _focusNodes.values.forEach((focusNode) => focusNode.dispose());
    _controllers.clear();
    _focusNodes.clear();
  }

  /// Update focus state for a specific field
  void _updateFocusState(String fieldKey) {
    _activeFocusField = _focusNodes[fieldKey]!.hasFocus ? fieldKey : null;
  }

  /// Check if a specific field is currently focused
  bool isFieldFocused(String fieldKey) {
    return _activeFocusField == fieldKey;
  }

  /// Get controller for a specific field
  TextEditingController? getController(String fieldKey) {
    return _controllers[fieldKey];
  }

  /// Get focus node for a specific field
  FocusNode? getFocusNode(String fieldKey) {
    return _focusNodes[fieldKey];
  }

  /// Clear all form data
  void clearFormData() {
    _controllers.values.forEach((controller) => controller.clear());
    _rememberMe = false;
    _activeFocusField = null;
  }

  /// Validate form data for a specific page
  bool validatePage(int pageIndex) {
    final page = BkData.BkOnboardingData.pages[pageIndex];
    if (!page.hasFormFields || page.formFields == null) {
      return true;
    }

    for (int i = 0; i < page.formFields!.length; i++) {
      final fieldKey = '${pageIndex}_${i}';
      final controller = _controllers[fieldKey];
      if (controller == null || controller.text.trim().isEmpty) {
        return false;
      }
    }

    return true;
  }

  /// Get form data for a specific page
  Map<String, String> getPageFormData(int pageIndex) {
    final Map<String, String> formData = {};
    final page = BkData.BkOnboardingData.pages[pageIndex];

    if (page.hasFormFields && page.formFields != null) {
      for (int i = 0; i < page.formFields!.length; i++) {
        final fieldKey = '${pageIndex}_${i}';
        final controller = _controllers[fieldKey];
        final field = page.formFields![i];

        if (controller != null) {
          formData[field.label] = controller.text.trim();
        }
      }
    }

    return formData;
  }
}
