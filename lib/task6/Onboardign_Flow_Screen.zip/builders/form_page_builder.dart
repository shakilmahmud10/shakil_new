import 'package:flutter/material.dart';
import '../../widgets/colors.dart';
import '../../widgets/style.dart';
import '../constants/onboarding_constants.dart';
import '../models/bk_onboarding_data.dart' as BkData;
import '../services/onboarding_navigation_service.dart';
import '../state/onboarding_state_manager.dart';
import '../widgets/bk_onboarding_components.dart' as BkWidgets;

/// Builder for form pages in the BK onboarding flow
class FormPageBuilder {
  /// Build a form page with input fields and validation
  static Widget build({
    required BkData.BkOnboardingPageData pageData,
    required int pageIndex,
    required OnboardingStateManager stateManager,
    required VoidCallback onPrevious,
    required VoidCallback onSkip,
    required PageController pageController,
    required BuildContext context,
    required VoidCallback onStateChanged,
  }) {
    return Scaffold(
      backgroundColor: bkBackgroundColor,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final screenHeight = constraints.maxHeight;
            final navBarHeight =
                (pageData.hasBackButton || pageData.hasSkipButton) ? 80.0 : 0.0;
            final contentHeight = screenHeight - navBarHeight;

            return Stack(
              children: [
                // Navigation bar
                if (pageData.hasBackButton || pageData.hasSkipButton)
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    height: navBarHeight,
                    child: _buildNavigationBar(pageData, onPrevious, onSkip),
                  ),

                // Main content
                Positioned(
                  top: navBarHeight,
                  left: 0,
                  right: 0,
                  height: contentHeight,
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(
                        horizontal: OnboardingConstants.cardPadding),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: contentHeight * 0.8,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Form container
                          _buildFormContainer(
                            pageData,
                            pageIndex,
                            stateManager,
                            pageController,
                            context,
                            onStateChanged,
                          ),

                          const SizedBox(
                              height: OnboardingConstants.mediumSpacing),

                          // Bottom link text
                          if (pageData.bottomText != null &&
                              pageData.bottomLinkText != null)
                            BkWidgets.BkBottomLinkText(
                              normalText: pageData.bottomText!,
                              linkText: pageData.bottomLinkText!,
                              onTap: () => OnboardingNavigationService
                                  .handleBottomLinkTap(
                                linkText: pageData.bottomLinkText!,
                                pageController: pageController,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  /// Build navigation bar for form pages
  static Widget _buildNavigationBar(
    BkData.BkOnboardingPageData pageData,
    VoidCallback onPrevious,
    VoidCallback onSkip,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(
          horizontal: OnboardingConstants.horizontalPadding,
          vertical: OnboardingConstants.cardPadding),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          if (pageData.hasBackButton)
            BkWidgets.BkBackButton(onTap: onPrevious)
          else
            const SizedBox(width: 40),
          if (pageData.hasSkipButton)
            BkWidgets.BkSkipButton(onTap: onSkip)
          else
            const SizedBox(width: 40),
        ],
      ),
    );
  }

  /// Build form container with fields and submit button
  static Widget _buildFormContainer(
    BkData.BkOnboardingPageData pageData,
    int pageIndex,
    OnboardingStateManager stateManager,
    PageController pageController,
    BuildContext context,
    VoidCallback onStateChanged,
  ) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(OnboardingConstants.formPadding),
      decoration: BoxDecoration(
        color: bhPrimary1.withOpacity(OnboardingConstants.backgroundOpacity),
        borderRadius: BorderRadius.circular(OnboardingConstants.borderRadius),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title
          Center(
            child: Text(
              pageData.title,
              style: bkHeaderTextStlye,
            ),
          ),
          const SizedBox(height: OnboardingConstants.largeSpacing),

          // Form fields
          if (pageData.formFields != null)
            ..._buildFormFields(
                pageData, pageIndex, stateManager, onStateChanged),

          // Checkbox section
          if (pageData.isLoginPage)
            _buildLoginCheckboxSection(stateManager, onStateChanged)
          else if (pageData.isSignupPage)
            _buildSignupCheckboxSection(stateManager, onStateChanged),

          const SizedBox(height: OnboardingConstants.buttonSpacing),

          // Submit button
          BkWidgets.BkCustomButton(
            text: pageData.buttonText,
            onTap: () => OnboardingNavigationService.handleFormPageNavigation(
              pageData: pageData,
              pageController: pageController,
              context: context,
            ),
            backgroundColor: bhPrimary1,
            textColor: Colors.white,
          ),
        ],
      ),
    );
  }

  /// Build form fields
  static List<Widget> _buildFormFields(
    BkData.BkOnboardingPageData pageData,
    int pageIndex,
    OnboardingStateManager stateManager,
    VoidCallback onStateChanged,
  ) {
    return pageData.formFields!.asMap().entries.map((entry) {
      final field = entry.value;
      final fieldKey = '${pageIndex}_${entry.key}';

      return Column(
        children: [
          BkWidgets.BkFormField(
            label: field.label,
            hint: field.hint,
            icon: field.icon,
            isPassword: field.isPassword,
            hasToggle: field.hasToggle,
            inputType: field.inputType,
            controller: stateManager.getController(fieldKey)!,
            focusNode: stateManager.getFocusNode(fieldKey)!,
            isFocused: stateManager.isFieldFocused(fieldKey),
          ),
          const SizedBox(height: OnboardingConstants.formFieldSpacing),
        ],
      );
    }).toList();
  }

  /// Build login page checkbox section
  static Widget _buildLoginCheckboxSection(
    OnboardingStateManager stateManager,
    VoidCallback onStateChanged,
  ) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(
          padding: const EdgeInsets.only(
              left: OnboardingConstants.navigationPadding),
          child: BkWidgets.BkCustomCheckbox(
            value: stateManager.rememberMe,
            onChanged: (value) {
              stateManager.rememberMe = value ?? false;
              onStateChanged();
            },
            text: OnboardingConstants.rememberMeText,
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
              right: OnboardingConstants.navigationPadding),
          child: InkWell(
            onTap: () {
              debugPrint('Forgot Password pressed');
            },
            child: Text(
              OnboardingConstants.forgotPasswordText,
              style: bkFormDetails.copyWith(
                fontSize: 14,
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// Build signup page checkbox section
  static Widget _buildSignupCheckboxSection(
    OnboardingStateManager stateManager,
    VoidCallback onStateChanged,
  ) {
    return Padding(
      padding:
          const EdgeInsets.only(left: OnboardingConstants.navigationPadding),
      child: BkWidgets.BkCustomCheckbox(
        value: stateManager.rememberMe,
        onChanged: (value) {
          stateManager.rememberMe = value ?? false;
          onStateChanged();
        },
        text: OnboardingConstants.termsAcceptanceText,
      ),
    );
  }
}
