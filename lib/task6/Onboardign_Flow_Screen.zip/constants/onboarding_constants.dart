/// Constants for BK Onboarding Flow
/// This file contains all magic numbers and repeated values to improve maintainability
class OnboardingConstants {
  // Page indices for navigation
  static const int loginOptionsPageIndex = 4;
  static const int loginFormPageIndex = 5;
  static const int signupFormPageIndex = 6;
  static const int welcomePagesCount = 3;

  // Animation durations
  static const Duration pageAnimationDuration = Duration(milliseconds: 300);
  static const Duration statusBarHideDelay = Duration(milliseconds: 1000);

  // UI dimensions
  static const double borderRadius = 16.0;
  static const double cardBorderRadius = 25.0;
  static const double buttonHeight = 50.0;
  static const double iconButtonSize = 100.0;
  static const double iconButtonHeight = 60.0;

  // Padding and margins
  static const double horizontalPadding = 24.0;
  static const double verticalPadding = 24.0;
  static const double cardPadding = 16.0;
  static const double formPadding = 24.0;

  // Spacing
  static const double smallSpacing = 12.0;
  static const double mediumSpacing = 24.0;
  static const double largeSpacing = 32.0;
  static const double extraLargeSpacing = 44.0;
  static const double formFieldSpacing = 30.0;
  static const double buttonSpacing = 40.0;
  static const double headerSpacing = 52.0;

  // Flex values
  static const int topSectionFlex = 6;
  static const int topSectionWithNavFlex = 7;
  static const int bottomSectionFlex = 4;
  static const int contentSectionFlex = 5;
  static const int contentSectionWithButtonsFlex = 6;
  static const int bottomLinkSectionFlex = 1;

  // Opacity values
  static const double cardOpacity = 0.3;
  static const double backgroundOpacity = 0.08;
  static const double borderOpacity = 0.3;

  // Navigation positions
  static const double topNavigationOffset = 50.0;
  static const double navigationPadding = 8.0;

  // Text and button labels
  static const String skipButtonText = 'Skip';
  static const String rememberMeText = 'Remember me';
  static const String forgotPasswordText = 'Forgot Password?';
  static const String termsAcceptanceText = 'I accept all Term of Conditions.';

  // Button text patterns for navigation logic
  static const String emailButtonPattern = 'Email';
  static const String signInButtonText = 'Sign In';
  static const String createAccountButtonText = 'Create Account';
  static const String createLinkPattern = 'Create';
}
