import 'package:flutter/material.dart';
import '../widgets/colors.dart';
import 'models/bk_onboarding_data.dart' as BkData;
import 'state/onboarding_state_manager.dart';
import 'services/onboarding_navigation_service.dart';
import 'builders/welcome_page_builder.dart';
import 'builders/standard_page_builder.dart';
import 'builders/form_page_builder.dart';
import 'mixins/system_ui_mixin.dart';

class BkOnboardingFlowScreen extends StatefulWidget {
  const BkOnboardingFlowScreen({super.key});

  @override
  State<BkOnboardingFlowScreen> createState() => _BkOnboardingFlowScreenState();
}

class _BkOnboardingFlowScreenState extends State<BkOnboardingFlowScreen>
    with WidgetsBindingObserver, SystemUIMixin {
  final PageController _pageController = PageController();
  final OnboardingStateManager _stateManager = OnboardingStateManager();
  int _currentPageIndex = 0;

  @override
  void initState() {
    super.initState();
    initializeSystemUI();
    _stateManager.initializeControllers();
  }

  @override
  void dispose() {
    disposeSystemUI();
    _pageController.dispose();
    _stateManager.disposeControllers();
    super.dispose();
  }

  void _nextPage() {
    onUserInteraction();
    if (_currentPageIndex < BkData.BkOnboardingData.pages.length - 1) {
      OnboardingNavigationService.nextPage(_pageController, _currentPageIndex);
    } else {
      OnboardingNavigationService.skipToMainMenu(context);
    }
  }

  void _previousPage() {
    onUserInteraction();
    OnboardingNavigationService.previousPage(
        _pageController, _currentPageIndex);
  }

  void _navigateToPage(int pageIndex) {
    onUserInteraction();
    OnboardingNavigationService.navigateToPage(_pageController, pageIndex);
  }

  void _onStateChanged() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    debugPrint(
        '🏗️ BkOnboardingFlowScreen.build called - current page: $_currentPageIndex');
    return Scaffold(
      backgroundColor: bkBackgroundColor,
      body: PageView.builder(
        controller: _pageController,
        onPageChanged: (index) {
          debugPrint('📄 Page changed from $_currentPageIndex to $index');
          setState(() {
            _currentPageIndex = index;
          });
        },
        itemCount: BkData.BkOnboardingData.pages.length,
        itemBuilder: (context, index) {
          final pageData = BkData.BkOnboardingData.pages[index];
          debugPrint('🏗️ Building page $index: ${pageData.title}');

          if (pageData.isWelcomePage) {
            debugPrint('🏗️ Building welcome page');
            return WelcomePageBuilder.build(
              pageData: pageData,
              pageIndex: index,
              onNext: _nextPage,
            );
          } else if (pageData.hasFormFields) {
            debugPrint('🏗️ Building form page');
            return FormPageBuilder.build(
              pageData: pageData,
              pageIndex: index,
              stateManager: _stateManager,
              onPrevious: _previousPage,
              onSkip: () => OnboardingNavigationService.skipToMainMenu(context),
              pageController: _pageController,
              context: context,
              onStateChanged: _onStateChanged,
            );
          } else {
            debugPrint('🏗️ Building standard page');
            return StandardPageBuilder.build(
              pageData: pageData,
              pageIndex: index,
              onNext: _nextPage,
              onPrevious: _previousPage,
              onSkip: () => OnboardingNavigationService.skipToMainMenu(context),
              pageController: _pageController,
              context: context,
            );
          }
        },
      ),
    );
  }
}
